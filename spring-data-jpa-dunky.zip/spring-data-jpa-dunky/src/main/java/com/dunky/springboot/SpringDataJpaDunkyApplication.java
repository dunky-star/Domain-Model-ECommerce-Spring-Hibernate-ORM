package com.dunky.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaDunkyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaDunkyApplication.class, args);
	}

}
